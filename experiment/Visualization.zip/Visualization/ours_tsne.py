import numpy as np
import matplotlib.pyplot as plt
from openTSNE import TSNE


def visual(feat):
    # t-SNE的最终结果的降维与可视化
    ts = TSNE(n_components=2, initialization='pca', random_state=0, n_iter=1500)

    x_ts = ts.fit(feat)

    print(x_ts.shape)  # [num, 2]

    x_min, x_max = x_ts.min(0), x_ts.max(0)

    x_final = (x_ts - x_min) / (x_max - x_min)

    return x_ts


color_map = ['b', 'r']


def plot_embedding_2D(data, label, title):
    """

    """

    # x_min, x_max = np.min(data, 0), np.max(data, 0)
    # data = (data - x_min) / (x_max - x_min)
    fig = plt.figure()
    for i in range(data.shape[0]):
        plt.plot(data[i, 0], data[i, 1], marker='o', markersize=4, color=color_map[int(label[i])])

    # Setting the font properties for the title
    # plt.title(f'{title}', fontname='Times New Roman', fontsize=26, fontweight='bold')

    # Customizing the tick labels with the specified font properties
    plt.xticks(fontname='Times New Roman', fontsize=18, fontweight='bold')
    plt.yticks(fontname='Times New Roman', fontsize=18, fontweight='bold')

    # Making the coordinate axis lines bolder
    ax = plt.gca()
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)

    # Reducing the whitespace around the plot
    plt.tight_layout()

    plt.savefig(f'./savefig/{title}', dpi=330)
    return fig


miRNA_final_embedding_fold_0_epoch_600 = np.load('sample_final_embedding_fold-0-epoch-4500.npy')
sample_final_label_fold_0_epoch_600 = np.load('sample_final_label_fold-0-epoch-4500.npy')

fig1 = plot_embedding_2D(data=visual(miRNA_final_embedding_fold_0_epoch_600), label=sample_final_label_fold_0_epoch_600,
                         title='epoch=4500')
plt.pause(50)
