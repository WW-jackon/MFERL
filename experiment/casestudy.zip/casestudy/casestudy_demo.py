import torch
import os
from new_model import MFERL
import random
import time
import numpy as np
import torch.utils.data.dataset as Dataset

import torch.utils.data.dataloader as DataLoader


def case_study_loading_data(param):
    md_matrix = np.loadtxt(os.path.join(param.datapath + '/matrix.csv'), dtype=int, delimiter=',')

    # get the edge of positives samples
    rng = np.random.default_rng(seed=42)  # 固定训练测试
    pos_samples = np.where(md_matrix == 1)
    pos_samples_shuffled = rng.permutation(pos_samples, axis=1)

    # get the edge of negative samples
    rng = np.random.default_rng(seed=42)
    neg_samples = np.where(md_matrix == 0)

    case_neg_samples = rng.permutation(neg_samples, axis=1)

    neg_samples_shuffled = rng.permutation(neg_samples, axis=1)[:, :pos_samples_shuffled.shape[1]]

    edge_idx_dict = dict()

    train_pos_edges = pos_samples_shuffled
    train_neg_edges = neg_samples_shuffled
    train_pos_edges = train_pos_edges.T
    train_neg_edges = train_neg_edges.T
    train_true_label = np.hstack((np.ones(train_pos_edges.shape[0]), np.zeros(train_neg_edges.shape[0])))
    train_true_label = np.array(train_true_label, dtype='float32')
    train_edges = np.vstack((train_pos_edges, train_neg_edges))
    np.savetxt('./train_test/train_pos.csv', train_pos_edges, delimiter=',')
    np.savetxt('./train_test/train_neg.csv', train_neg_edges, delimiter=',')

    edge_idx_dict['train_Edges'] = train_edges
    edge_idx_dict['train_Labels'] = train_true_label

    edge_idx_dict['true_md'] = md_matrix  ##*

    return edge_idx_dict, pos_samples_shuffled, case_neg_samples


class Config2:
    def __init__(self):
        self.datapath = './datasets/821-2115-9589'
        self.kfold = 5
        self.batchSize = 128
        # self.ratio = 0.2
        self.epoch = 30

        # self.gcn_layers = 2
        # self.view = 3
        self.fm = 128
        self.fd = 128
        self.inSize = 128

        self.outSize = 128
        # self.nodeNum = 0
        self.hdnDropout = 0.5
        self.fcDropout = 0.5
        # self.maskMDI = False

        self.channel_num = 5
        self.embedding_dim = 128

        self.miRNA_numbers = 821
        self.circRNA_numbers = 2115

        self.ssl_temp = 0.1
        self.proto_reg = 8e-8
        self.ssl_reg = 1e-5
        self.alpha = 1

        self.r = 0.5  # 创建相似图

        self.doc_dim = 256
        self.role = 256
        self.pro_dim = 128

        self.ctd_dim = 30
        self.doc2vec_dim = 256
        self.role2vec_dim = 256
        self.kmer_dim = 340
        self.lr = 0.01  # 0.01#学习率

        self.device = torch.device('cuda')


class CVEdgeDataset(Dataset.Dataset):
    def __init__(self, edges, labels):
        self.Data = edges
        self.Label = labels

    def __len__(self):
        return len(self.Label)

    def __getitem__(self, index):
        data = self.Data[index]
        label = self.Label[index]
        return data, label


# 加载全部全部的关联矩阵内元素的索引
class CVEdgeDataset_loadAllData(Dataset.Dataset):
    def __init__(self, edges):
        self.Data = edges

    def __len__(self):
        return len(self.Data)

    def __getitem__(self, index):
        data = self.Data[index]
        return data


if __name__ == "__main__":
    param = Config2()
    train_data, case_pos_samples, case_neg_samples = case_study_loading_data(param)
    # result = train_test(train_data, param, state='valid')

    train_edges = train_data['train_Edges']
    train_labels = train_data['train_Labels']
    trainEdges = CVEdgeDataset(train_edges, train_labels)
    trainLoader = DataLoader.DataLoader(trainEdges, batch_size=param.batchSize, shuffle=True, num_workers=0)

    test_pos_edges = case_pos_samples.T
    test_neg_edges = case_neg_samples.T
    # test_true_label = np.hstack((np.ones(test_pos_edges.shape[0]), np.zeros(test_neg_edges.shape[0])))
    # test_true_label = np.array(test_true_label, dtype='float32')
    test_edges = np.vstack((test_pos_edges, test_neg_edges))
    # test_edges_tensor = torch.from_numpy(test_edges)
    # test_edges_tensor_cuda = test_edges_tensor.cuda()
    # testEdges = CVEdgeDataset(test_edges, test_true_label )
    # testLoader = DataLoader.DataLoader(testEdges, batch_size=param.batchSize, shuffle=True, num_workers=0)

    all_Edges = CVEdgeDataset_loadAllData(test_edges)
    all_Loader = DataLoader.DataLoader(all_Edges, batch_size=1024, shuffle=False, num_workers=0)

    # model
    model = MSFEICL(param)  ##*
    model.cuda()
    optimizer = torch.optim.Adam(model.parameters(), lr=param.lr, weight_decay=0.0)

    for e in range(param.epoch):
        running_loss = 0.0  ###
        epo_label = []
        epo_score = []
        print("epoch：", e + 1)
        model.train()
        start = time.time()
        for i, item in enumerate(trainLoader):
            data, label = item
            train_data = data.cuda()
            true_label = label.cuda()  ###
            pre_score, ssl_loss = model(train_data)  ##*
            train_loss = torch.nn.BCELoss()
            loss = train_loss(pre_score, true_label) + ssl_loss
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()
            running_loss += loss.item()  ###
            print(f"After batch {i + 1}: loss= {loss:.3f};", end='\n')  ###
            batch_score = pre_score.cpu().detach().numpy()
            epo_score = np.append(epo_score, batch_score)
            epo_label = np.append(epo_label, label.numpy())
        end = time.time()
        print('Time：%.2f \n' % (end - start))

    model.eval()

    all_value = []
    all_xy = []

    with torch.no_grad():
        for i, data in enumerate(all_Loader):
            all_data = data.cuda()
            all_score, allssl_loss = model(all_data)  ##*
            all_xy.append(data)
            all_value.append(all_score)
            print('all_score:', all_score)


